
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>My Blog</title>

    <!-- Fonts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Nunito';
        }
    </style>

</head>

<body>

@if(Auth::user())

    <div class="container">
        @if(Auth::user()->role_id == 1)
            <span class="text-align">
        Logged in Admin
    </span>
        @endif
        @if(Auth::user()->role_id == 2)
            <span  class="text-align">
        Logged in Blogger
    </span>
        @endif
        @if(Auth::user()->role_id == 3)
            <span class="text-align">
        Logged in User
    </span>
        @endif

            <?php
            $back_button = false;
            $name = Route::currentRouteName();
            if (strpos($name, 'post') !== false) {
                $back_button = true;
            }
            ?>
        <div class="row">
            <div class="col-1">
                <form action="{{route('.logout')}}" method="post">@csrf
                    <button type="submit" class="btn btn-primary btn-sm" > Logout </button>
                </form>
            </div>
            @if($back_button)
                <div class="col-4">
                    <a href="{{ url()->previous()}}" class="btn btn-primary btn-sm" >Back</a>
                </div>
            @endif
        </div>

    </div>
@endif

@yield('content')

</body>
</html>
