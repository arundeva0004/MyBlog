<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{

    public function index()
    {
        if(Auth::user()->role_id != 1){
            $posts = Post::where(['created_by' => Auth::user()->id])->get();
        } else {
            $posts = Post::all();
        }

        return view('dashboard.user.home', compact('posts'));
    }


    function create(Request $request){
        //validate request
        $request->validate([
           'name' => 'required',
           'email' => 'required|email|unique:users,email',
           'role_id' => 'required',
           'password' => 'required|min:5|max:30',
           'cpassword' => 'required|min:5|max:30|same:password'
        ]);

        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->role_id = $request->role_id;
        $user->password = Hash::make($request->password);

        $register = $user->save();

        if($register){
            return redirect()->route('.login')->with('success','You are now registered successfully ');
        } else {
            return redirect()->back()->with('fail','Something went wrong, failed to register');
        }

    }

    function check(Request $request){
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'password' => 'required|min:5|max:30'
        ],[
            'email.exists' => 'This email is not exist on users table'
        ]);

        $creds = $request->only('email','password');
        if(Auth::attempt($creds)){
            return redirect()->route('.home');
        } else{
            return redirect()->back()->with('fail', 'Incorrect credentials');
        }
    }

    function logout(){
        //dd('wel');
        Auth::logout();
        return redirect()->route('.login');
    }


}
